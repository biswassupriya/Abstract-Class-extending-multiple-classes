public class Childrens extends SupriyaParents {
    public int age ;
    @Override
    public void natureofParents() {
        System.out.println("kind soul and have a big heart");
    }
    public  int childage(int a){
        age = a;
        return age;
    }
}
