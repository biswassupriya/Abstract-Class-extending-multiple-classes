public abstract class  SupriyaParents extends GrandParent {
    public abstract void natureofParents();
    public void parentsAre(){
        System.out.println("very helpful and life long dad helped people");
    }


}
