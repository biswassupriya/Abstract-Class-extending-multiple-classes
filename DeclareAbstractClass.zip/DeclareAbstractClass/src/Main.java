public class Main {
    public static void main(String[] args) {
        Childrens c = new Childrens();
        System.out.println("I AM THE CHILD");
        c.natureofParents();
        c.behaviour();
        c.height();
        c.parentsAre();
        //c.childage(38);
        System.out.println(c.childage(38));

        SupriyaParents sp = new Childrens();
        System.out.println("WE ARE THE PARENTS");
        sp.natureofParents();
        sp.parentsAre();
        sp.behaviour();
        sp.height();

        GrandParent gp = new Childrens();
        System.out.println("THIS IS GRANDPARENTS ");
            gp.behaviour();
            gp.height();



        }


    }

