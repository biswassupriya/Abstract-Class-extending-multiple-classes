public abstract class GrandParent {
    public void height(){
        System.out.println("Grandparents are Tall");
    }
    public void behaviour(){
        System.out.println("Grandparents are very kind and generous");
    }
}
